"""Stream a selected archive into a new local file and verify upstream metadata."""

import hashlib
import ntpath
import os
import re
import tempfile
from pathlib import Path, PureWindowsPath
from urllib.parse import urlsplit

import httpx

from .api import NexusError

# Recognize archive suffixes in upstream names as well as in the detected format.
_ARCHIVE_EXTENSIONS = {
    "zip",
    "7z",
    "rar",
    "tar",
    "gz",
    "tgz",
    "bz2",
    "tbz",
    "tbz2",
    "xz",
    "txz",
    "zst",
    "tzst",
    "lz",
    "lzma",
    "tar.gz",
    "tar.bz2",
    "tar.xz",
    "tar.zst",
    "tar.lz",
    "tar.lzma",
    "fomod",
    "omod",
    "bsa",
    "ba2",
    "pak",
    "jar",
    "mrpack",
}


def _reserved_filename(name: str) -> bool:
    if hasattr(ntpath, "isreserved"):
        return ntpath.isreserved(name)
    return PureWindowsPath(name).is_reserved()  # Python 3.11 and 3.12


def archive_name(value: object) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value.startswith(".")
        or re.search(r'[<>:"/\\|?*\x00-\x1f\x7f-\x9f\ud800-\udfff]', value)
        or value != value.rstrip(" .")
        or len(value.encode("utf-8")) > 255
        or _reserved_filename(value)
    ):
        raise ValueError("Nexus supplied an invalid archive filename.")
    return value


def _named_archive(value: object, *, require_known_suffix: bool) -> str | None:
    try:
        name = archive_name(value)
    except ValueError:
        return None
    suffix = PureWindowsPath(name).suffix
    if not suffix or (
        require_known_suffix and suffix[1:].lower() not in _ARCHIVE_EXTENSIONS
    ):
        return None
    return name


def _download_name(metadata: dict) -> str:
    row = metadata["modFile"]
    detected = row.get("detectedFileExtension")
    extension = detected.lower().removeprefix(".") if isinstance(detected, str) else ""
    known_type = extension in _ARCHIVE_EXTENSIONS

    # With a detected archive type, do not misread a display version like "1.2"
    # as a file extension. Without one, preserve safe legacy filenames.
    v1 = metadata.get("v1")
    if isinstance(v1, dict) and (
        name := _named_archive(v1.get("file_name"), require_known_suffix=known_type)
    ):
        return name
    # A URI containing a path is an object key, not a source of local path parts.
    if name := _named_archive(row.get("uri"), require_known_suffix=known_type):
        return name

    if not known_type:
        raise ValueError("Nexus did not supply a supported archive extension.")

    # The GraphQL UID identifies the release across games; names and file IDs alone do not.
    uid = row.get("uid")
    if type(uid) is int and 0 < uid < 10**20:
        uid = str(uid)
    if not isinstance(uid, str) or not re.fullmatch(r"[1-9][0-9]{0,19}", uid):
        raise ValueError(
            "Nexus did not supply a valid file UID for the archive filename."
        )

    title = row.get("name")
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", title) if isinstance(title, str) else ""
    slug = slug.strip("._-")[:80].rstrip("._-") or "file"
    return f"nexus-{slug}-{uid}.{extension}"


def checksums(metadata: dict) -> dict[str, str]:
    expected = {}
    for source in (
        metadata["modFile"],
        metadata.get("v1", {}),
        metadata.get("v3", {}).get("data", {}),
    ):
        for algo in ("sha256", "sha1", "md5"):
            if digest := source.get(algo):
                if (
                    not isinstance(digest, str)
                    or not re.fullmatch(r"[a-fA-F0-9]+", digest)
                    or len(digest) != hashlib.new(algo).digest_size * 2
                ):
                    raise ValueError(f"Invalid upstream {algo} checksum.")
                if algo in expected and expected[algo] != digest.lower():
                    raise ValueError(f"Conflicting upstream {algo} checksums.")
                expected[algo] = digest.lower()
    return expected


def download_path(directory: Path, metadata: dict) -> Path:
    name = _download_name(metadata)
    destination = directory.expanduser().resolve() / name
    if os.path.lexists(destination):
        raise FileExistsError(f"A file already exists at {destination}.")
    return destination


async def save_archive(
    http: httpx.AsyncClient, url: str, metadata: dict, directory: Path
) -> dict:
    destination = download_path(directory, metadata)
    destination.parent.mkdir(parents=True, exist_ok=True)
    expected = checksums(metadata)
    hashes = {algo: hashlib.new(algo) for algo in {"sha256", *expected}}
    expected_size = metadata["modFile"].get("sizeInBytes")
    if expected_size is None:
        expected_size = metadata.get("v3", {}).get("data", {}).get("size_in_bytes")
    total = 0
    temp_path = None
    try:
        # Follow HTTPS redirects explicitly. This client carries no API credentials.
        for _ in range(8):
            parsed = urlsplit(url)
            if (
                parsed.scheme != "https"
                or not parsed.hostname
                or parsed.username
                or parsed.password
            ):
                raise ValueError("Invalid Nexus mirror URL.")
            async with http.stream(
                "GET",
                url,
                headers={"Accept-Encoding": "identity"},
                follow_redirects=False,
            ) as response:
                if response.is_redirect and "location" in response.headers:
                    url = str(response.url.join(response.headers["location"]))
                    continue
                if response.status_code != 200:
                    raise NexusError(
                        f"Nexus mirror returned HTTP {response.status_code}.",
                        response.status_code,
                    )
                if "text/html" in response.headers.get("Content-Type", "").lower():
                    raise NexusError(
                        "Nexus mirror returned a web page instead of an archive."
                    )
                if (
                    response.headers.get("Content-Encoding", "identity").lower()
                    != "identity"
                ):
                    raise NexusError(
                        "Nexus mirror returned a non-identity content encoding."
                    )
                size_header = response.headers.get("Content-Length")
                if size_header is not None:
                    length = int(size_header)
                    if expected_size is not None and int(expected_size) != length:
                        raise ValueError(
                            "Content-Length does not match Nexus file metadata."
                        )
                    expected_size = length
                with tempfile.NamedTemporaryFile(
                    dir=destination.parent,
                    prefix=".nexus-",
                    suffix=".part",
                    delete=False,
                ) as out:
                    temp_path = Path(out.name)
                    async for chunk in response.aiter_bytes(128 * 1024):
                        total += len(chunk)
                        if expected_size is not None and total > int(expected_size):
                            raise ValueError("Received more bytes than Nexus reported.")
                        out.write(chunk)
                        for digest in hashes.values():
                            digest.update(chunk)
                break
        else:
            raise NexusError("Too many Nexus mirror redirects.")
        if expected_size is not None and total != int(expected_size):
            raise ValueError("Downloaded size does not match Nexus file metadata.")
        actual = {algo: digest.hexdigest() for algo, digest in hashes.items()}
        if any(actual[algo] != wanted for algo, wanted in expected.items()):
            raise ValueError(
                "Downloaded archive checksum does not match Nexus metadata."
            )
        if os.name == "nt":
            os.rename(
                temp_path, destination
            )  # Windows rename refuses existing targets.
        else:
            os.link(
                temp_path, destination
            )  # Atomically publish without replacing an existing file.
        return {
            "path": str(destination),
            "bytes": total,
            "hashes": actual,
            "verifiedUpstreamHashes": expected,
        }
    except httpx.RequestError as exc:
        raise NexusError(f"Download interrupted ({type(exc).__name__}).") from None
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)
